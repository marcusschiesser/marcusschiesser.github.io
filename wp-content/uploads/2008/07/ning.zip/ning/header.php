<?php include (TEMPLATEPATH . '/config.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>

<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->

<link rel="stylesheet" type="text/css" media="screen,projection" href="http://static.ning.com/xn/css?host=http%3A%2F%2F<?= $NING_SITE ?>&href=%2Fxn_resources%2Fwidgets%2Findex%2Fcss%2Fcommon.css,%2Fxn_resources%2Fwidgets%2Findex%2Fcss%2Fcomponent.css,%2Ftheme<?= $THEME_NO ?>.css,%2Fcustom<?= $CUSTOM_NO ?>.css,%2Fnavigation.css,%2Fxn_resources%2Fwidgets%2Fgroups%2Fcss%2Fmodule.css,%2Fxn_resources%2Fwidgets%2Fforum%2Fcss%2Fmodule.css,%2Fxn_resources%2Fwidgets%2Fvideo%2Fcss%2Fmodule.css,%2Fxn%2Fstatic-6.11.8.1%2Fningbar%2Fcss%2Fningbar-v1-compressed.css,%2Fxn%2Fningbar.css"/>

<!--<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />-->
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php wp_head(); ?>
</head>
<body>
<div id="xn_bar">
	<div id="xn_bar_menu">
	<div id="xn_bar_menu_more">
			<?php include (TEMPLATEPATH . '/searchform.php'); ?>
	</div>
	</div>
	<div id="xn_bar_panel">
	</div>
</div>
<div id="xg" class=" xg_widget_main xg_widget_main_index xg_widget_main_index_index">
    <div id="xg_head">
                    <div id="xg_masthead">

                <a id="application_name_header_link" href="/"><img src="<?= $LOGO_URL ?>"></a>
                            </div><!--/#xg_masthead-->
            <div id="xg_navigation" >
				
<a class="main" href="http://<?= $NING_SITE ?>"><span style="display:none;">Startseite</span></a>
<a class="profile" href="http://<?= $NING_SITE ?>/profiles"><span style="display:none;">Meine Seite</span></a>
<a class="members" href="http://<?= $NING_SITE ?>/profiles/friend/list"><span style="display:none;">Mitglieder</span></a>
<a class="forum" href="http://<?= $NING_SITE ?>/forum"><span style="display:none;">Forum</span></a>
<a class="groups" href="http://<?= $NING_SITE ?>/groups"><span style="display:none;">Gruppen / Bands</span></a>
<a class="photo" href="http://<?= $NING_SITE ?>/photo"><span style="display:none;">Fotos</span></a>
<a class="video" href="http://<?= $NING_SITE ?>/video"><span style="display:none;">Videos</span></a>
<a class="invite" href="http://<?= $NING_SITE ?>/invite"><span style="display:none;">Einladen</span></a>
<a class="blog active" href="http://<?= $BLOG_SITE ?>"><span style="display:none;">Blog</span></a>
<a class="shop" href="http://shop.metaltribe.de/" target="_blank"><span style="display:none;">Shop</span></a>

				
            </div><!--/#xg_navigation-->

            </div><!--/#xg_head-->


