<form method="get" id="xn_bar_menu_search" action="<?php bloginfo('url'); ?>/">
<fieldset>
<input class="text" type="text" value="<?php the_search_query(); ?>" name="s" id="xn_bar_menu_search_query" />
<a id="xn_bar_menu_search_submit" href="#search" onClick="parentNode.submit()">Search</a><span class="after"></span>
</fieldset>
</form>