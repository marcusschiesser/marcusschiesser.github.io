<?php get_header(); ?>

<div id="xg_body">
<div  class='xg_colgroup first-child last-child'>

<div  class='xg_3col first-child'>

	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>


				<h1><a style="color: #DDEEFF; text-decoration:none" href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
			<div class="xg_module">
			<div class="xg_module_head">
				<small>Geschrieben am <?php the_time('j. F Y') ?> von <?php the_author() ?> </small>
			</div>
			<div class="xg_module_body pad">
				<div class="discussion">
				<div class="firstpost">
				<div class="description">
					<?php the_content('Read the rest of this entry &raquo;'); ?>
				</div></div></div>
			</div>
			<div class="xg_module_body xg_module_actionlinks">
				<p class="postmetadata"><?php the_tags('Tags: ', ', ', '<br />'); ?> Gepostet in <?php the_category(', ') ?> | <?php edit_post_link('Editieren', '', ' | '); ?>  <?php comments_popup_link('Kommentar schreiben &#187;', '1 Kommentar &#187;', '% Kommentare &#187;'); ?></p>
				<?php comments_template(); ?>
			</div>
			</div>

		<?php endwhile; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>

	<?php else : ?>

		<h2 class="center">Not Found</h2>
		<p class="center">Sorry, but you are looking for something that isn't here.</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<?php endif; ?>

</div>

<div  class='xg_1col last-child'>
<?php get_sidebar(); ?>
</div>

</div>
</div>

<?php get_footer(); ?>
