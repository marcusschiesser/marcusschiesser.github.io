<?php include (TEMPLATEPATH . '/config.php'); ?>

    <div id="xg_foot">

        <p class="left">
			<?= $COPYRIGHT ?> &nbsp;&nbsp;
            <a href="http://<?= $NING_SITE ?>/main/index/report">Fehler melden</a> |
            <a href="http://<?= $NING_SITE ?>/main/index/feedback">Feedback</a> |
            <a href="http://<?= $NING_SITE ?>/main/authorization/privacyPolicy?previousUrl=http%3A%2F%2Fmetaltribe.ning.com%2F">Datenschutz-Erklärung</a> |
            <a href="http://<?= $NING_SITE ?>/main/authorization/termsOfService?previousUrl=http%3A%2F%2Fmetaltribe.ning.com%2F">AGB</a> | 
            <a href="http://<?= $NING_SITE ?>/main/authorization/impressum?previousUrl=http%3A%2F%2Fmetaltribe.ning.com%2F">Impressum</a>

        </p>
        <p class="right">Verbreite die Botschaft! <a href="http://<?= $NING_SITE ?>/main/embeddable/list">Hole Dir ein <?= $SITE_NAME ?>-Banner</a></p>
    </div><!--/#xg_foot-->

</div><!--/#xg-->

		<?php wp_footer(); ?>
</body>
</html>
