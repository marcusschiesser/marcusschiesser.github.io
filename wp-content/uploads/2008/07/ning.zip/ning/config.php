<?php 
        $SITE_NAME = 'Metaltribe';
	$NING_SITE = 'metaltribe.ning.com';
	$BLOG_SITE = 'blog.metaltribe.de';
	$COPYRIGHT = '(C) 2008 Ulrich Kerler & Marcus Schiesser';
	$THEME_NO = 66; // Retrieve THEME_NO and CUSTOM_NO from the CSS link from the HTML-source of your ning site
	$CUSTOM_NO = 29; 
	$LOGO_URL = 'http://api.ning.com/files/zXR0dA4dEqScu5HS5WaXAY-EqWgqKtmuRvsXJ-ZscwAc3amtnXiA48tgiQKw93xPrAdV2ZYWsXHg5SLtp*yQ50uEhp7zVRGU/banner_metal.jpg?xn_auth=no&type=jpeg';
?>