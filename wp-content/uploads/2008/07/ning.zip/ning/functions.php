<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<div class="xg_module"><div id="%1$s" class="xg_module_body %2$s">',
        'after_widget' => '</div></div>',
        'before_title' => '<div class="xg_module_head">',
        'after_title' => '</div>',
    ));
?>
